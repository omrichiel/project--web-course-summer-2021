function showAnswer(i) {
  var q = "question" + i;
  var element = document.getElementById(q);
  element.classList.toggle("mystyle");
}