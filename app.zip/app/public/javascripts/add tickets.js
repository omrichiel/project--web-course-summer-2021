function newOffer(eventName, category) {
    document.getElementById()
}